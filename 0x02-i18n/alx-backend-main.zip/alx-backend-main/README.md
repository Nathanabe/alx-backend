# ALX Backend

![Repo size](https://img.shields.io/github/repo-size/B3zaleel/alx-backend)
![Pep8 style](https://img.shields.io/badge/PEP8-style%20guide-purple?style=round-square)
![Latest commit](https://img.shields.io/github/last-commit/B3zaleel/alx-backend/main?style=round-square)

This repo contains projects for learning backend development concepts.
